package TicTacToe;

public class Main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TicTacToee TicTacToe = new TicTacToee();
		TicTacToe.main();
	}
}
